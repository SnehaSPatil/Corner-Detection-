function thArray= CornerDetection(sigma,A,neigh, Lth)
 
%reading images
im1 = imread(A);

im1 = im2double((im1));

%comment this code for Building1
im1 = im2double(rgb2gray(im1));
% Fetching 1d gaussian matrix
 
% It works with this filter but is very slow
%im=GuassianFilter(A,sigma);

im = imgaussfilt(im1,sigma);
 
% 
% %Gradient
 [Jx,Jy] = gradient(im);
 
 thArray = [];
 
 rows = size(Jx,1);
 cols = size(Jx,2);
 counter = 1;
 for i = 1: rows
     for j = 1 : cols
         if i- neigh > 0 && i+neigh < rows && j-neigh > 0 && j+neigh < cols
                sumJx = 0;
                sumJy = 0;
                sumJxJy = 0;
                stI = i-neigh;
                enI = i+neigh;
                stJ = j-neigh;
                enJ = j+neigh;
                
            for m = stI : enI
                for n = stJ : enJ
                    sumJx = sumJx + Jx(m,n)*Jx(m,n); 
                    sumJy = sumJy + Jy(m,n)*Jy(m,n);
                    sumJxJy = sumJxJy + Jx(m,n)* Jy(m,n);
                end
            end
              
           %calculating input to eigen vector
             Cmatrix = [sumJx,sumJxJy;sumJxJy,sumJy];
             
            %getting eigen matrix
             [vec,vals] = eig(Cmatrix);
             lambda = vals(2,2);
  
             if vals(1,1) ~= 0 && vals(2,2) ~=0
                if vals(1,1) < vals(2,2)
                    lambda = vals(1,1);
                end
                
                if lambda > Lth
                    histArray(counter) = lambda;
                    
                    thArray(counter,1) = i;
                    thArray(counter,2) = j;
                    thArray(counter,3) = lambda;
                    
                    counter = counter +1;
                end
                
                
             end
             
         end
     end
 end
 
 [x,y] = size(thArray);
 
 for i = 1  : x
    for j = i+1 : x
        
        if thArray(i,3) < thArray(j,3)
            arryTemp1=thArray(i,1);
            arryTemp2=thArray(i,2);
            arryTemp3=thArray(i,3);
 
            thArray(i,3)=thArray(j,3);
            thArray(i,2)=thArray(j,2);
            thArray(i,1)=thArray(j,1);
 
            thArray(j,1)=arryTemp1;
            thArray(j,2)=arryTemp2;
            thArray(j,3)=arryTemp3;
        end
    end
 end
 
% remove close by pixels
for i = 1 : x
    
    if thArray(i,1) ~= 0 && thArray(i,2) ~=0 
    
    for j = i+1 : x
    
        if thArray(j,1) ~= 0 && thArray(j,2) ~=0 
        difX  = thArray(i,1) - thArray(j,1);
        absdX = abs(difX);
        difY = thArray(i,2) - thArray(j,2);
        absdY = abs(difY);
            if absdX <= 10 && absdY <= 10
                %check neighbours
                thArray(j,1) = 0;
                thArray(j,2) = 0;
            end 
        end
    
    end
    end
end
 
 
index = 1;
%copy non zero elements to a new array
for i = 1 : x
    if thArray(i,1) ~= 0 && thArray(i,2) ~=0
        sortedArray(index,2) = thArray(i,1);
        sortedArray(index,1) = thArray(i,2);
        index = index +1;
    end
end
 
 color = {'white'};
 RGB = insertMarker(im1,sortedArray,'o','color',color,'size',5);
 imshow(RGB,[]);